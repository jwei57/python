const fs = require('fs')
const reader = require('xlsx')

const { Client } = require('ssh2')

const hosts = []
let cmdExecuted = [0]
let currCmd = 0
let currIndex = 0
const excelResultJson = []

function passwdExec(stream, dataStr, outputMatch, input) {
  if (dataStr.toLowerCase().indexOf(outputMatch) === 0 && !cmdExecuted[currCmd]) {
    cmdExecuted[currCmd] = 1
    currCmd++
    cmdExecuted.push(0)
    stream.write(input + '\n');
  }
}

function passwdCmd(conn) {
  conn.exec('passwd', { pty: true }, function (err, stream) {
    stream.on('close', (code, signal) => {
      //
    }).on('data', (data) => {
      const dataStr = data.toString()
      passwdExec(stream, dataStr, "current", hosts[currIndex].currpwd)
      passwdExec(stream, dataStr, "new", hosts[currIndex].newpwd)
      passwdExec(stream, dataStr, "retype", hosts[currIndex].newpwd)
      console.log(data.toString())
      if (dataStr.toLowerCase().includes("successfully")) {
        cmd1(conn)
      }
    }).stderr.on('data', (data) => {
      stream.close();
    });
  })
}

function cmd1(conn) {
  let finData = ""
  conn.exec('uptime', (err, stream) => {
    if (err) throw err;
    stream.on('close', (code, signal) => {
      fs.writeFile('output_txt/' + currIndex + '_' + hosts[currIndex].host + '.txt', finData, function (err) {
        if (err) console.log(err);
      });
      excelResultJson.push({
        index: currIndex,
        host: hosts[currIndex].host,
        port: hosts[currIndex].port,
        output: finData
      })
      console.log('Stream :: close :: code: ' + code + ', signal: ' + signal);
      conn.end();
      // NEXT HOST OR NEXT CMD
      currIndex++
      if (currIndex !== hosts.length) {
        console.log('-- -- NEXT HOST -- --')
        main()
      } else {
        console.log('-- -- ALL TASKS FINISHED @ '+ new Date().toLocaleString() +' -- --')
        writeXlsx()
      }
    }).on('data', (data) => {
      console.log('STDOUT: ' + data);
      finData += data
    }).stderr.on('data', (data) => {
      console.log('STDERR: ' + data);
    });
  });
}

function main() {
  const conn = new Client();
  conn.on('ready', () => {
    console.log('CONNECTED :: ' + hosts[currIndex].host);
    passwdCmd(conn)
  }).connect({
    host: hosts[currIndex].host,
    username: hosts[currIndex].username,
    port: hosts[currIndex].port,
    password: hosts[currIndex].currpwd
  });
}

fs.readFile("hosts.txt", {encoding: 'utf-8'}, function(err, data) {
  if (err) throw err
  data.split('\r\n').map(line => {
    var [host, port] = line.split(":")
    var [port, username, currpwd, newpwd] = port.split(";;")
    hosts.push({host, port, username, currpwd, newpwd})
  })
  main()
})

function writeXlsx() {
  let workBook = reader.utils.book_new();
  const workSheet = reader.utils.json_to_sheet(excelResultJson);
  reader.utils.book_append_sheet(workBook, workSheet, 'results');
  let exportFileName = new Date().getTime() + '_results.xlsx';
  reader.writeFile(workBook, exportFileName);
}