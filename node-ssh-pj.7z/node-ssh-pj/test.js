const fs = require('fs');
const hosts = []

fs.readFile("hosts.txt", {encoding: 'utf-8'}, function(err, data) {
	if (err) throw err
	data.split('\r\n').map(line => {
		var [host, port] = line.split(":")
		var [port, username, currpwd, newpwd] = port.split(";;")
		hosts.push({host, port, username, currpwd, newpwd})
	})
	console.log(hosts)
});

